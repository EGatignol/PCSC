#include "classic_chord.hh"
/* -------------------------------------------------------------------------- */

std:vector<double> ClassicChord::NextX(Function unnamed, std::vector<double> unnamed, std::vector<double> unnamed){

}



/* --------------------------------------------------------------------------- */


