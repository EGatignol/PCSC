#include "newton.hh"
/* -------------------------------------------------------------------------- */

std:vector<double> Newton::NextX(Function unnamed, std::vector<double> unnamed, std::vector<double> unnamed){

}



/* --------------------------------------------------------------------------- */


