#include "polynomial_1_to_n.hh"
/* -------------------------------------------------------------------------- */

Eigen::Matrix<double, -1, 1> Polynomial1ToN::Func(std::vector<double> X){

}



/* --------------------------------------------------------------------------- */

Eigen::Matrix<double, -1, -1> Polynomial1ToN::DerivedFunc(std::vector<double> X){

}



/* --------------------------------------------------------------------------- */


