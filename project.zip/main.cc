
#include <cstdio>
#include <cstdlib>
#include <iostream>

int main(int argc, char ** argv){

/// ... your code here ...

  return EXIT_FAILURE;
}