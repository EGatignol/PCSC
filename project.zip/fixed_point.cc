#include "fixed_point.hh"
/* -------------------------------------------------------------------------- */

std:vector<double> FixedPoint::NextX(Function unnamed, std::vector<double> unnamed, std::vector<double> unnamed){

}



/* --------------------------------------------------------------------------- */

ResultMethod FixedPoint::MethodFindRoot(Function unnamed){

}



/* --------------------------------------------------------------------------- */


