#ifndef __M_TO_N__HH__
#define __M_TO_N__HH__

/* -------------------------------------------------------------------------- */
#include "function.hh"

/**
  * Documentation TODO
  */

class MToN: public Function{
};

/* -------------------------------------------------------------------------- */
#endif //__M_TO_N__HH__
