#ifndef __CLASSIC_CHORD__HH__
#define __CLASSIC_CHORD__HH__

/* -------------------------------------------------------------------------- */
#include "fixed_point.hh"

/**
  * Documentation TODO
  */

class ClassicChord: public FixedPoint{

  /* ------------------------------------------------------------------------ */
  /* Methods                                                                  */
  /* ------------------------------------------------------------------------ */

public:

  //! Documentation TODO
  std:vector<double> NextX(Function unnamed, std::vector<double> unnamed, std::vector<double> unnamed);

};

/* -------------------------------------------------------------------------- */
#endif //__CLASSIC_CHORD__HH__
